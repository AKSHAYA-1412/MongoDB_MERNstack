import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import "./BookingForm.css"; // Import the CSS file

const BookingForm = () => {
  const { id } = useParams(); // Get the doctor's ID from the URL
  const [formData, setFormData] = useState({
    fullName: "",
    dateOfBirth: "",
    contactNumber: "",
    email: "",
    medications: "",
    allergies: "",
    medicalHistory: "",
    symptoms: "",
    insuranceProvider: "",
    policyNumber: "",
    preferredDate: "",
    preferredTime: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here (e.g., sending to an API)
    console.log(formData);
    alert("Appointment scheduled successfully!"); // Placeholder for success message
  };

  return (
    <div>
      <h1>Booking Appointment</h1>
      <h2>With Doctor ID: {id}</h2>
      <form onSubmit={handleSubmit}>
        <h3>Personal Information</h3>
        <label>
          Full Name:
          <input
            type="text"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Date of Birth:
          <input
            type="date"
            name="dateOfBirth"
            value={formData.dateOfBirth}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Contact Number:
          <input
            type="tel"
            name="contactNumber"
            value={formData.contactNumber}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Email Address:
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </label>

        <h3>Medical Information</h3>
        <label>
          Current Medications (with dosages):
          <textarea
            name="medications"
            value={formData.medications}
            onChange={handleChange}
            required
          ></textarea>
        </label>
        <label>
          Allergies:
          <textarea
            name="allergies"
            value={formData.allergies}
            onChange={handleChange}
            required
          ></textarea>
        </label>
        <label>
          Medical History:
          <textarea
            name="medicalHistory"
            value={formData.medicalHistory}
            onChange={handleChange}
            required
          ></textarea>
        </label>

        <h3>Reason for Visit</h3>
        <label>
          Symptoms:
          <textarea
            name="symptoms"
            value={formData.symptoms}
            onChange={handleChange}
            required
          ></textarea>
        </label>

        <h3>Insurance Information</h3>
        <label>
          Insurance Provider:
          <input
            type="text"
            name="insuranceProvider"
            value={formData.insuranceProvider}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Policy Number:
          <input
            type="text"
            name="policyNumber"
            value={formData.policyNumber}
            onChange={handleChange}
            required
          />
        </label>

        <h3>Logistics</h3>
        <label>
          Preferred Appointment Date:
          <input
            type="date"
            name="preferredDate"
            value={formData.preferredDate}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Preferred Appointment Time:
          <input
            type="time"
            name="preferredTime"
            value={formData.preferredTime}
            onChange={handleChange}
            required
          />
        </label>

        <button type="submit">Submit</button>
      </form>

      <Link
        to={`/doctor/${id}`}
        style={{ display: "block", marginTop: "20px" }}
      >
        Back to Doctor Details
      </Link>
    </div>
  );
};

export default BookingForm;
