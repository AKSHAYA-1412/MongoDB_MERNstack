import React from "react";
import { Link } from "react-router-dom";
import "./DoctorList.css"; // Import the CSS file

// Example data with specialties. Replace this with dynamic data if needed.
const doctors = [
  { id: 1, name: "Dr. Mark", specialty: "Cardiologist" },
  { id: 2, name: "Dr. Domnic", specialty: "Cardiologist" },
  { id: 3, name: "Dr. Jane Smith", specialty: "Dermatologist" },
  { id: 4, name: "Dr. John Doe", specialty: "Dermatologist" },
  { id: 5, name: "Dr. Emily Clark", specialty: "Pediatrician" },
  { id: 6, name: "Dr. Michael Lewis", specialty: "Neurologist" },
  { id: 7, name: "Dr. Susan Parker", specialty: "Cardiologist" },
  { id: 8, name: "Dr. Steven White", specialty: "Neurologist" },
  { id: 9, name: "Dr. Linda Green", specialty: "Pediatrician" },
  { id: 10, name: "Dr. Robert Lee", specialty: "Orthopedic Surgeon" },
  { id: 11, name: "Dr. Sarah Brown", specialty: "Orthopedic Surgeon" },
  { id: 12, name: "Dr. Kevin Miller", specialty: "Gastroenterologist" },
  { id: 13, name: "Dr. Laura Wilson", specialty: "Gastroenterologist" },
  { id: 14, name: "Dr. Alice Cooper", specialty: "Endocrinologist" },
  { id: 15, name: "Dr. James Anderson", specialty: "Endocrinologist" },
];

// Group doctors by specialty
const groupDoctorsBySpecialty = () => {
  return doctors.reduce((grouped, doctor) => {
    const { specialty } = doctor;
    if (!grouped[specialty]) {
      grouped[specialty] = [];
    }
    grouped[specialty].push(doctor);
    return grouped;
  }, {});
};

const DoctorList = () => {
  const groupedDoctors = groupDoctorsBySpecialty();

  return (
    <div>
      <h1>Doctor List</h1>
      {Object.keys(groupedDoctors).map((specialty) => (
        <div key={specialty}>
          <h2>{specialty}</h2>
          <ol>
            {groupedDoctors[specialty].map((doctor) => (
              <li key={doctor.id}>
                <h3>{doctor.name}</h3>
                <Link to={`/doctor/${doctor.id}`}>View Details</Link>
              </li>
            ))}
          </ol>
        </div>
      ))}
    </div>
  );
};

export default DoctorList;
