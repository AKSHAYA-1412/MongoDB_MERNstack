import React from "react";

const ConfirmationPage = () => {
  return (
    <div>
      <h1>Appointment Confirmed</h1>
      <p>
        Thank you for booking an appointment! You will receive a confirmation
        email shortly.
      </p>
    </div>
  );
};

export default ConfirmationPage;
