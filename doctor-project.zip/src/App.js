import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import DoctorList from "./DoctorList"; // Ensure this path is correct
import DoctorDetails from "./DoctorDetails"; // Adjust paths as needed
import BookingForm from "./BookingForm"; // Adjust paths as needed
import ConfirmationPage from "./ConfirmationPage"; // Adjust paths as needed

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<DoctorList />} />
        <Route path="/doctor/:id" element={<DoctorDetails />} />
        <Route path="/book/:id" element={<BookingForm />} />
        <Route path="/confirmation" element={<ConfirmationPage />} />
      </Routes>
    </Router>
  );
};

export default App;
