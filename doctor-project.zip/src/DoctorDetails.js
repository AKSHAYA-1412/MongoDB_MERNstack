import React from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import "./DoctorDetails.css";
// Example data. In a real application, this would come from an API or database.
const doctors = [
  {
    id: 1,
    name: "Dr. Mark",
    specialty: "Cardiologist",
    experience: 10,
    rating: 4.5,
  },
  {
    id: 2,
    name: "Dr. Domnic",
    specialty: "Cardiologist",
    experience: 8,
    rating: 4.7,
  },
  {
    id: 3,
    name: "Dr. Jane Smith",
    specialty: "Dermatologist",
    experience: 5,
    rating: 4.3,
  },
  {
    id: 4,
    name: "Dr. John Doe",
    specialty: "Dermatologist",
    experience: 6,
    rating: 4.2,
  },
  {
    id: 5,
    name: "Dr. Emily Clark",
    specialty: "Pediatrician",
    experience: 12,
    rating: 4.8,
  },
  {
    id: 6,
    name: "Dr. Michael Lewis",
    specialty: "Neurologist",
    experience: 9,
    rating: 4.6,
  },
  {
    id: 7,
    name: "Dr. Susan Parker",
    specialty: "Cardiologist",
    experience: 7,
    rating: 4.4,
  },
  {
    id: 8,
    name: "Dr. Steven White",
    specialty: "Neurologist",
    experience: 10,
    rating: 4.5,
  },
  {
    id: 9,
    name: "Dr. Linda Green",
    specialty: "Pediatrician",
    experience: 8,
    rating: 4.3,
  },
  {
    id: 10,
    name: "Dr. Robert Lee",
    specialty: "Orthopedic Surgeon",
    experience: 15,
    rating: 4.7,
  },
  {
    id: 11,
    name: "Dr. Sarah Brown",
    specialty: "Orthopedic Surgeon",
    experience: 9,
    rating: 4.6,
  },
  {
    id: 12,
    name: "Dr. Kevin Miller",
    specialty: "Gastroenterologist",
    experience: 11,
    rating: 4.4,
  },
  {
    id: 13,
    name: "Dr. Laura Wilson",
    specialty: "Gastroenterologist",
    experience: 7,
    rating: 4.5,
  },
  {
    id: 14,
    name: "Dr. Alice Cooper",
    specialty: "Endocrinologist",
    experience: 10,
    rating: 4.6,
  },
  {
    id: 15,
    name: "Dr. James Anderson",
    specialty: "Endocrinologist",
    experience: 5,
    rating: 4.3,
  },
];

const DoctorDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate(); // Hook for navigation
  const doctor = doctors.find((doc) => doc.id === parseInt(id));

  if (!doctor) {
    return <h2>Doctor not found!</h2>;
  }

  const handleBookAppointment = () => {
    navigate(`/book/${doctor.id}`); // Navigate to BookingForm page with doctor's id
  };

  return (
    <div>
      <h1>{doctor.name}</h1>
      <h2>Specialization: {doctor.specialty}</h2>
      <p>
        Experience: {doctor.experience} years
        <br />
        Rating: {doctor.rating} ⭐
      </p>
      <p>
        {doctor.name} is a highly skilled {doctor.specialty} with over{" "}
        {doctor.experience} years of experience. Known for their excellent
        patient care and dedication, they have received a rating of{" "}
        {doctor.rating} stars from their patients. Their expertise includes
        diagnosing and treating various conditions related to their specialty.
        Patients appreciate their comprehensive approach and compassionate
        demeanor. If you're looking for a knowledgeable professional in this
        field, {doctor.name} is a great choice.
      </p>
      <button onClick={handleBookAppointment}>Book Appointment</button>
      <br />
      <Link to="/">Back to Doctor List</Link>
    </div>
  );
};

export default DoctorDetails;
